const firebaseConfig = {

  apiKey: "AIzaSyDxSiV-r1SjALtdCRedGSWrW-UVzrndrMo",

  authDomain: "lab-webowe.firebaseapp.com",

  projectId: "lab-webowe",

  storageBucket: "lab-webowe.firebasestorage.app",

  messagingSenderId: "915128638545",

  appId: "1:915128638545:web:d04cc7e290d9240dbd6c70"

};
