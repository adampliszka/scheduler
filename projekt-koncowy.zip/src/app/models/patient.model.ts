import {Physician} from './physician.model';
import {Appointment, AppointmentDate} from './appointment.model';

enum sex {
  MALE,
  FEMALE,
}
export interface Patient {
  id: number;
  name: string;
  patientSex: sex;
  age: number;
  appointments: AppointmentDate[];
}
