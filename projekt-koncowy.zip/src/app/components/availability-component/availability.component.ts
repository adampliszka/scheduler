import { Component, inject, OnInit, OnDestroy } from '@angular/core';
import { SchedulerService } from '../../services/scheduler.service';
import { AuthService } from '../../services/auth.service';
import { Physician } from '../../models/physician.model';
import { FormsModule } from '@angular/forms';
import {AsyncPipe, DatePipe, NgForOf, NgIf} from '@angular/common';
import { Observable, of, BehaviorSubject, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import {doc, docData, Firestore} from '@angular/fire/firestore';

@Component({
  selector: 'app-availability',
  templateUrl: './availability.component.html',
  imports: [
    FormsModule,
    NgForOf,
    NgIf,
    DatePipe
  ],
  styleUrls: ['./availability.component.css']
})
export class AvailabilityComponent implements OnInit, OnDestroy {
  userName: string = '';
  isPhysician: boolean = false;
  physician: Physician | undefined;
  private firestore = inject(Firestore);
  private destroy$ = new Subject<void>();

  constructor(protected authService: AuthService, protected schedulerService: SchedulerService) {}

  ngOnInit(): void {
    this.authService.getUser().subscribe(user => {
      if (user) {
        const userRef = doc(this.firestore, `users/${user.uid}`);
        docData(userRef).subscribe(userData => {
          // @ts-ignore
          this.userName = userData.name;
          // @ts-ignore
          this.isPhysician = userData.roles.physician;
          this.schedulerService.getPhysicianByName(this.userName).subscribe(
            physician => {
              this.physician = physician;
              //console.log(physician?.workingDaysOfTheWeek[4] == true);
            }
          );
        });
      } else {
        this.userName = 'Register';
        this.isPhysician = false;
      }
    });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  addWorkingPeriod() {
    if (!this.physician?.availableForThePeriods) {
      this.physician!.availableForThePeriods = [];
    }
    this.physician!.availableForThePeriods.push({ startDate: new Date(), endDate: new Date() });
  }

  removeWorkingPeriod(index: number) {
    if (this.physician?.availableForThePeriods) {
      this.physician.availableForThePeriods.splice(index, 1);
    }
  }

  addWorkingHour() {
    if (!this.physician?.workingHours) {
      this.physician!.workingHours = [];
    }
    this.physician!.workingHours.push({ start: '', end: '' });
  }

  removeWorkingHour(index: number) {
    if (this.physician?.workingHours) {
      this.physician.workingHours.splice(index, 1);
    }
  }

  addAbsence() {
    if (!this.physician?.absences) {
      this.physician!.absences = [];
    }
    this.physician!.absences.push(new Date());
  }

  removeAbsence(index: number) {
    if (this.physician?.absences) {
      this.physician.absences.splice(index, 1);
    }
  }

  addManualAvailability() {
    if (!this.physician?.manualAvailability) {
      this.physician!.manualAvailability = [];
    }
    this.physician!.manualAvailability.push({ date: new Date(), slots: [] });
  }

  removeManualAvailability(index: number) {
    if (this.physician?.manualAvailability) {
      this.physician.manualAvailability.splice(index, 1);
    }
  }

  toggleWorkingDay(day: number) {
    if (!this.physician?.workingDaysOfTheWeek) {
      this.physician!.workingDaysOfTheWeek = [false,false,false,false,false,false,false];
    }
    // @ts-ignore
    this.physician.workingDaysOfTheWeek[day] = !this.physician.workingDaysOfTheWeek[day];
  }

  isWorkingDay(day: number): boolean  {
    return this.physician?.workingDaysOfTheWeek[day] || false;
  }

  saveChanges() {
    const appointmentDates = this.physician?.appointments;

    if (this.physician){
      let manualBad = false;
      let hoursBad = false;
      let absenceBad = false;
      let dayBad = false;
      let periodBad = false;
      if (appointmentDates) {
        for (let appointmentDate of appointmentDates) {
          for (let appointment of appointmentDate.slots) {
            const date = new Date(appointmentDate.date);
            const time = appointment.time.split(':');
            const hourDuration = Math.floor(appointment.durationSlots / 2);
            const minuteDuration = (appointment.durationSlots % 2) * 30;
            const appointmentStartHours = Number(time[0]) % 24;
            const appointmentStartMinutes = Number(time[1]);
            const appointmentEndHours = (Number(time[0]) + Number(hourDuration) + (Number(time[1] + Number(minuteDuration)) >= 60 ? 1 : 0)) % 24;
            const appointmentEndMinutes = (Number(time[1]) + Number(minuteDuration)) % 60;
            let isPast = false;
            if(date < new Date()){
              isPast = true;
            }

            for (let hours of this.physician.workingHours) {
              if (appointmentStartHours < Number(hours.start) ||
                appointmentStartHours == Number(hours.start) && appointmentStartMinutes < Number(hours.start) ||
                appointmentEndHours > Number(hours.end) ||
                appointmentEndHours == Number(hours.end) && appointmentEndMinutes > Number(hours.end)) {
                if (!isPast){
                  hoursBad = true;
                }
              }
            }
            if (this.physician.absences) {
              for (let absence of this.physician.absences) {
                if (appointmentDate.date == absence) {
                  if (!isPast){
                    absenceBad = true;
                    }
                }
              }
            }

            let localPeriodOk = false;
            for (let period of this.physician.availableForThePeriods) {
              if (date >= new Date(period.startDate) && date <= new Date(period.endDate)) {
                localPeriodOk = true;
              }
            }
            if(!localPeriodOk && !isPast){
              periodBad = true;
            }

            if(!this.physician.workingDaysOfTheWeek[date.getDay()]){
              if (!isPast){
                dayBad = true;
              }
            }

            let localManualOk = false;
            if (this.physician.manualAvailability) {
              for (let manualAvailability of this.physician.manualAvailability) {
                if (date == manualAvailability.date && appointment.time in manualAvailability.slots) {
                  localManualOk = true;
                }
              }
            }
            if(!localManualOk){
              if (!isPast){
                manualBad = true;
              }
            }
          }
        }
      }
      if(!manualBad || (!hoursBad && !absenceBad && !dayBad && !periodBad) ){
        this.schedulerService.updatePhysician(this.physician).subscribe(updatedPhysician => {
          console.log('Physician updated:', updatedPhysician);
        });
      }
      else {
        alert("Warning: New schedule conflicts with existing appointments. Cancel them first.");
      }

    }
  }
}
