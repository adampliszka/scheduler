import { Component } from '@angular/core';

@Component({
  selector: 'app-reservation-form-component',
  imports: [],
  templateUrl: './reservation-form-component.component.html',
  styleUrl: './reservation-form-component.component.css'
})
export class ReservationFormComponentComponent {

}
