import { Component } from '@angular/core';

@Component({
  selector: 'app-cart-item-component',
  imports: [],
  templateUrl: './cart-item-component.component.html',
  styleUrl: './cart-item-component.component.css'
})
export class CartItemComponentComponent {

}
