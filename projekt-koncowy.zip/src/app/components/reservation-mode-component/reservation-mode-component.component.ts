import { Component } from '@angular/core';

@Component({
  selector: 'app-reservation-mode-component',
  imports: [],
  templateUrl: './reservation-mode-component.component.html',
  styleUrl: './reservation-mode-component.component.css'
})
export class ReservationModeComponentComponent {

}
